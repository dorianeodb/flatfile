# TV Show


------------------------------


## Description

###Test & exercice pour le cours de CMS (qui n'en est pas un) sur le site Tumblr. 

[Voir le Tumblr](http://cms-dodb.tumblr.com)


Police : Gibson


Favicon
![Favicon](https://d30y9cdsu7xlg0.cloudfront.net/noun-svg/101195.svg?Expires=1475047195&Signature=A5HTGroiK9fKmtCju8eA~DTOzxYbvC9rSMoTxjQB7v~PBzk7zHg4d8ut81rP28EqiDQppJygN51CBZV26LOYZySKMgLme-VArauHHuutLblnkVZWjwMMeq7N8adRo8eSnUvWwaxp8xvJTGsN~Vtqm5yrYhVRnPFUXz21r2KvtEw_&Key-Pair-Id=APKAI5ZVHAXN65CHVU2Q)

Bannière web
![Bannière Web](https://s-media-cache-ak0.pinimg.com/564x/28/1b/30/281b308e1933f314b6b693a4d48ae8be.jpg)

Couleurs :
 
- #110250
- #dd1f75

Premier article :

Image
![Image](https://s-media-cache-ak0.pinimg.com/originals/b6/84/5e/b6845e17ed65d10b5be6049b8c3012d0.png)



One of my mission this year is : Watch all tv shows & movies 
that I have on my list (there are soooo many !)
Since this is one of my favourite hobbie, I choose to talk about 
it in my blog. For me, series & movies represents an excellent way to escape reality & relax 
after a long day (as in license where we go back home at 8pm…).
So, i’m gonna present you all of my favourite tv shows & movies !
